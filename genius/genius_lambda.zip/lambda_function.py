import json
import boto3
import os
import requests
from bs4 import BeautifulSoup

# AWS set up
AWS_REGION = 'us-east-2'
s3 = boto3.client('s3', region_name=AWS_REGION)
dynamodb = boto3.resource('dynamodb', region_name=AWS_REGION)

# environment variables
GENIUS_API_TOKEN = os.environ['GENIUS_API_TOKEN']
bucket_name = 'genius-s3-bucket-sowder'
table_name = 'genius-ddb-table'

def lambda_handler(event, context):
    table = dynamodb.Table(table_name)

    for record in event['Records']:
        body = json.loads(record['body'])
        title = body['title']
        artist = body['artist']
        track_id = body['track_id']

        # Genius API search
        headers = {'Authorization': f'Bearer {GENIUS_API_TOKEN}'}
        search_url = f"https://api.genius.com/search?q={title} {artist}"
        response = requests.get(search_url, headers=headers).json()

        try:
            song_info = response['response']['hits'][0]['result']
            song_url = song_info['url']
            lyrics = "Lyrics not found."
            try:
                headers_scrape = {'User-Agent': 'Mozilla/5.0'}
                lyrics_page = requests.get(song_url, headers=headers_scrape, timeout=10)
                soup = BeautifulSoup(lyrics_page.text, 'html.parser')

                divs = soup.find_all("div", {"data-lyrics-container": "true"})
                extracted = "\n".join(div.get_text(separator="\n").strip() for div in divs)

                if extracted.strip():
                    lyrics = extracted
                else:
                    # fallback
                    alt_divs = soup.select("div[class^='Lyrics__Container']")
                    fallback = "\n".join(div.get_text(separator="\n").strip() for div in alt_divs)
                    if fallback.strip():
                        lyrics = fallback
                    else:
                        print(f"No lyrics found for {song_url}")
            except Exception as e:
                print(f"Scraping failed for {song_url}: {e}")

        except (IndexError, AttributeError, KeyError):
            song_url = "Not found"
            lyrics = "Lyrics not found."

        # save to S3
        s3_key = f"lyrics/{track_id}.json"
        s3.put_object(
            Bucket=bucket_name,
            Key=s3_key,
            Body=json.dumps({
                'track_id': track_id,
                'title': title,
                'artist': artist,
                'url': song_url,
                'lyrics': lyrics
            })
        )
        print(f"Saved to S3: {s3_key}")

        # save to DynamoDB
        table.put_item(
            Item={
                'user_id': track_id,
                'title': title,
                'artist': artist,
                'url': song_url,
                'lyrics': lyrics
            }
        )

    return {
        'statusCode': 200,
        'body': json.dumps('Processed successfully')
    }
